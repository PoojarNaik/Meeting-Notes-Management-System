-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 29, 2018 at 06:53 PM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 7.0.25-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `document`
--

CREATE TABLE `document` (
  `did` int(11) NOT NULL,
  `filename` varchar(120) NOT NULL,
  `uid` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `meeting`
--

CREATE TABLE `meeting` (
  `mid` int(11) NOT NULL,
  `pname` varchar(120) NOT NULL,
  `mdesc` varchar(120) NOT NULL,
  `date` date NOT NULL,
  `uid` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meeting`
--

INSERT INTO `meeting` (`mid`, `pname`, `mdesc`, `date`, `uid`, `filename`) VALUES
(1, 'ddd', 'ddddd', '0000-00-00', 0, 'w3school.png'),
(2, 'ddd', 'dddd', '0000-00-00', 0, 'w3school1.png'),
(3, 'sss', 'sss', '0000-00-00', 0, 'Laundry_Management_System.docx'),
(4, 'blog', 'creating blog system', '0000-00-00', 0, 'Laundry_Management_System1.docx'),
(5, 'jjjj', 'jjjjj', '0000-00-00', 0, 'Laundry_Management_System2.docx'),
(6, 'mjjj', 'jjks', '0000-00-00', 0, 'Laundry_Management_System3.docx'),
(7, 'jjjjs', 'skskks', '0000-00-00', 0, 'Laundry_Management_System4.docx'),
(10, 'cc', 'cccc', '0000-00-00', 0, 'Laundry_Management_System8.docx'),
(11, '', '', '2029-03-18', 0, 'paytm.png'),
(41, 'myproject', 'meetings', '2018-03-18', 1, '4_LOF9.docx'),
(42, 'admin created', 'display and download', '2018-03-18', 1, '4_LOF10.docx'),
(43, 'sssss', 'ssssss', '2018-03-18', 1, 'paytm7.png'),
(44, 'admin', 'aaaaa', '2018-03-18', 1, 'paytm8.png'),
(45, 'user', '1234', '2018-03-18', 2, 'paytm9.png'),
(46, 'user', '12344444444', '2018-03-18', 2, 'paytm10.png');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `email` varchar(120) NOT NULL,
  `password` varchar(11) NOT NULL,
  `status` int(1) NOT NULL COMMENT '1-admin 0-user'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `name`, `email`, `password`, `status`) VALUES
(1, 'pooja', 'pj@gmail.com', 'pooja', 1),
(2, 'user', 'user@gmail.com', '1234', 0),
(3, 'admin', 'admin@gmail.com', 'admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `pid` int(11) NOT NULL,
  `pname` varchar(120) NOT NULL,
  `pdesc` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`pid`, `pname`, `pdesc`) VALUES
(9, 'hh', 'hh'),
(10, '', ''),
(11, 'uu', 'uuu'),
(12, 'kk', 'kk'),
(13, 'blog system', 'creating posting '),
(14, 'kk', 'kkk'),
(15, 'meeting notes management', 'documents management');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `document`
--
ALTER TABLE `document`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `meeting`
--
ALTER TABLE `meeting`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`pid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `document`
--
ALTER TABLE `document`
  MODIFY `did` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `meeting`
--
ALTER TABLE `meeting`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
