<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
	.navbar{
		background-color:#563d7c;
		color:white;
    }
    
	.tab {
		float: left;
		border: 1px solid #ccc;
		background-color: #eadef7;
		width: 20%;
		height: 100%;
    }
/* Style the buttons inside the tab */
	.tab button {
		display: block;
		background-color: inherit;
		color: black;
		padding: 22px 16px;
		width: 100%;
		border: none;
		outline: none;
		text-align: left;
		cursor: pointer;
		transition: 0.3s;
		font-size: 17px;
    }
/* Change background color of buttons on hover */
	.tab button:hover {
		background-color: #ddc5f7;
    }
/* Create an active/current "tab button" class */
	.tab button.active {
		background-color: #ccc;
    }
/* Style the tab content */
	.tabcontent {
		float: left;
		padding: 0px 12px;
		border: 1px solid #ccc;
		width: 80%;
		border-left: none;
		height: 100%;
    }
	input{
		width: 80%;
  }
  .btn{
    min-width: 80px;
    max-width: 80px;
	background-color: #563d7c;
}
</style>
</head>

<body>
<!--vertical tab-->
  <nav class="navbar">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#"><font color="white">Meeting Notes Management</font></a>
    </div>
    <ul class="nav navbar-nav navbar-right">
	 <li> <a href="#"><span class="glyphicon glyphicon-user"></span><font color="white"><?php echo $_SESSION['name'] ?></font></a></li>
      <li><a href="<?php base_url('logout')?>"><span class="glyphicon glyphicon-log-in" ></span><font color="white"> Logout</font></a></li>
    </ul>
  </div>
</nav>
<div class="tab">
<b>
    <button class="tablinks" onclick="openCity(event, 'addproject')" id="defaultOpen">Add Projects</button>
  <button class="tablinks" onclick="openCity(event, 'createmeetings')">Create Meetings</button>
  <button class="tablinks" onclick="openCity(event, 'viewmeetings')">View Meetings</button>
  </b>
</div>


<!--Adding projects-->
<div id="addproject" class="tabcontent">
  <h3><center>Add Projects</center></h3>
<?php echo form_open_multipart('meetingctr/insertp');?>
    <table id="project" style="margin-top:5%;" class="table table-border">
      <tr>
        <td>Project Name:</td>
        <td><input type="text" name="pname"/>
      </tr>
      <tr>
        <td>Project Discription</td>
        <td><input type="text" name="pdesc"/>
        </tr>
      </table>
      <input type="submit" value="add" class="btn btn-primary" data-toggle="tooltip" title="Click here"/>
    </form>
</div>


<!-- Creating meetings -->
<div id="createmeetings" class="tabcontent">
  <center><h3>Create Meetings</h3></center>
	<?php echo form_open_multipart('meetingctr/file_data');?>
		<table id="create"  style="margin-top:10%;" class="table table-border">
		  <tr>
			<th>Project Name</th>
			<td><select name='pname' class="form-control">
				<?php
				foreach($projects as $row)
				{
				  echo '<option value="'.$row['pname'].'">'.$row['pname'].'</option>';
				}
				?>
				</select></td>
			</tr>
		<tr>
        <th>Meeting Purpose</th>
      <td><input type="text" name="mdesc" id="mdesc"/></td>
    </tr>
      <tr>
        <th>Date </th>
		<td><input type="date" name="date" value="<?php echo date("y/m/d");?>" required/></td>
    </tr>
      <tr><th>Upload Document</th>
      <td><input type="file" name="filename" id="filename"/></td></tr>
	   <tr>
	  <td> <input type="submit" value="submit" class="btn btn-primary" data-toggle="tooltip" title="Click here"/></td>
	  <td> <input type="reset" value="clear" class="btn btn-primary" data-toggle="tooltip" title="Click here"/></td>
	   </tr>
	 </table>
	  
    
</form>
</div>


<!--view meetings-->
<div id="viewmeetings" class="tabcontent">
  <h1 style="font-style:italic"><center>Meeting Details</center></h1>
  <hr />
  <h2>List of Meetings</h2>
  <?php if(count($projects1)){?>
    <table class="table table-bordered table-striped table-hover">
    <thead>
      <tr>
      <th>Employee Name</th>
      <th>Project Name</th>
      <th>Description</th>
      <th>Date</th>
      <th>Documents</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($projects1 as $key=>$pic): ?>
      <?php //print_r($pic); ?>
      <tr>
      <td><?php echo $pic['uname']; ?></td>
      <td><?php echo $pic['pname']; ?></td>
      <td><?php echo $pic['mdesc']; ?></td>
      <td><?php echo $pic['date']; ?></td>
      <td><a href="<?php echo base_url().'fileupload/files/'.$pic['filename'];?>" target="_blank"><img src="<?php base_url().'fileupload/files/'.$pic['filename'];?>"><?php echo $pic['filename'];?></a></td>
      </tr>
    <?php endforeach ?>
  </tbody><?php } ?>
    </table>
</div>

<script>
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>

</div>
</body>
</html>
