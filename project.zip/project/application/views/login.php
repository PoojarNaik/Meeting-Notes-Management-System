<html>
  <head>
      <title>Form Login</title>
        <style>

	body
		{
		font-family:Calibri;
		margin:50px;
		}
	#form-login{
		  margin:auto;
		  width:50%;
		  height:60%;
		  padding:10px;
		  border:1px #ccc solid;
		  font-size:18px;
		  font-weight:bold;
		  background-color: #a4b4fc;
		  color:#FF6600;
		}
		
	input[type=text], input[type=password] {
		width: 100%;
		padding: 12px 20px;
		margin: 8px 0;
		display: inline-block;
		border: 1px solid #ccc;
		box-sizing: border-box;
}

	.error
		{
		color:#FF6600;
		font-size:11px;
		}

	.registrationform
		{
		max-width: 350px;
		padding: 40px 40px;
		height:350px;
		background: rgba(0, 0, 0, 0.3);
		color: #FFF !important;
		font-weight:bold;
		font-family:Calibri;
		font-size:15px;
		}
		body{
		height: 100%;
		background-repeat: no-repeat;
		background-color:rgba(145, 10, 208, 0.68);

	</style>
</head>

<body>
<form action="<?php echo base_url('index.php/meetingctr/login')?>" method="post" name="login">
<center>
 <div class="span6">
    <h1 class="muted">Meeting Notes Management</h1>
 </div>
	<div class="registrationform">
		<h3>Plase Login First</h3><br>
      <table border="0" cellpadding="4">
        <tr>
          <td><b>Username<b></td>
          <td>:</td>
          <td><input type="text" size="40" name="name" value="" placeholder="Enter username" required></td>
        </tr>
        <tr>
          <td><b>Password<b></td>
          <td>:</td>
          <td><input type="password" size="40" name="password" placeholder="Enter Password" required value=""> <br/></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><input type="submit" name="login" value="Login"> </td>
        </tr>
      </table>
  </div>
</center>
</form>
</body>
</html>
