<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
<body>
<div class="container">

  <h1 style="font-style:italic">Meeting Details</h1>
	<hr />
<h2>List of Meetings</h2>
  <?php if(count($picture_list)){?>
	  <table class="table table-bordered">
		<thead>
		  <tr>
			<th>Project Name</th>
			<th>Description</th>
      <th>Date</th>
			<th>Documents</th>
		  </tr>
		</thead>
		<tbody>
		<?php foreach ($picture_list as $pic): ?>
		  <tr>
			<td><?=$pic->pname;?></td>
			<td><?=$pic->mdesc;?></td>
      <td><?=$pic->date;?></td>
			<td><a href="<?=base_url().'fileupload/files/'.$pic->filename;?>" target="_blank"><img src="<?=base_url().'fileupload/files/'.$pic->filename;?>"><?php echo $pic->filename;?></a></td>
		  </tr>
		<?php endforeach ?>
		</tbody>
	  </table>
	  <!-- <br />
	  <a href="<?=base_url().'upload/form';?>" class="btn btn-primary">Upload More</a>
  <?php } else { ?>
    <h4>No Pictures have been uploaded!. Click this button to <a href="<?=base_url().'upload/form';?>" class="btn btn-primary">upload</a></h4>
  <?php } ?>
  <br /><br />
<p class="footer" style="bottom:0">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p> -->

</div>

</body>
</html>
