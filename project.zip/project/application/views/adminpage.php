<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
	header, footer {
		padding: 1em;
		color: white;
		background-color:;
		clear: left;
		text-align: center;
}
	.navbar{
		background-color:#563d7c;
}
.registrationform
{
    padding: 30px;
    background: rgba(0, 0, 0, 0.3);
    color: #FFF !important;
    height: auto;
}

	.tab {
		float: left;
		border: 1px solid #ccc;
		background-color: #f1f1f1;
		width: 20%;
		height: 100%;
}

/* Style the buttons inside the tab */
	.tab button {
		display: block;
		background-color: inherit;
		color: black;
		padding: 22px 16px;
		width: 100%;
		border: none;
		outline: none;
		text-align: left;
		cursor: pointer;
		transition: 0.3s;
		font-size: 17px;
}
/* Change background color of buttons on hover */
	.tab button:hover {
		background-color: #ddd;
}
/* Create an active/current "tab button" class */
	.tab button.active {
		background-color: #ccc;
}
/* Style the tab content */
	.tabcontent {
		float: left;
		padding: 0px 12px;
		border: 1px solid #ccc;
		width: 80%;
		border-left: none;
		height: 100%;
}
	input{
		width: 80%;
}
</style>
</head>

<body>
<!--vertical tab-->
  <nav class="navbar">
  <div class="container-fluid">
    <div class="navbar-header">
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="<?php //base_url('logout')?>"><span class="glyphicon glyphicon-log-in" ></span> Logout</a></li>
    </ul>
  </div>
</nav>



 <center>
            <div class="registrationform">
                <div class="form-horizontal">
                    <fieldset>
                        <legend>Welcome Manager<i class="fa fa-pencil pull-right"></i></legend>
                       	<div class="form-group">
							<center><input type="button" style="width:150px;" class="btn btn-primary" onclick="location.href='addproject';" value="Add Project"/>
							<br/><br/>
						<input type="button" style="width:150px;" class="btn btn-primary" onclick="location.href='createmeeting';" value="Create Meetings" />
						<br/><br/>
						<input type="button"  style="width:150px;" class="btn btn-primary" onclick="location.href='viewlic.php';" value="View All Meetings" />
						<br/><br/>
						 <br/></center>
	    </div>
	</fieldset>
</div>
</div>
