<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
	header, footer {
		padding: 1em;
		color: white;
		background-color:;
		clear: left;
		text-align: center;
}
	.navbar{
		background-color:#563d7c;
}
</style>
</head>

<body>
<!--vertical tab-->
  <nav class="navbar">
  <div class="container-fluid">
    <div class="navbar-header">
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="<?php base_url('logout')?>"><span class="glyphicon glyphicon-log-in" ></span> Logout</a></li>
    </ul>
  </div>
</nav>

<h3>create your meetings</h3>
<?php echo form_open_multipart('meetingctr/get_projectname');?>
  <table id="create"  style="margin-top:10%;" class="table table-border">
    <tr>
    <th>Project Name</th>
    <td><select name='pname' class="form-control">
      <?php
      foreach($projects as $row)
      {
        echo '<option value="'.$row->pname.'">'.$row->pname.'</option>';
      }
      ?>
      </select></td>
    </tr>
  <tr>
      <th>Meeting Purpose</th>
    <td><input type="text" name="mdesc" id="mdesc"/></td>
  </tr>
    <tr>
      <th>Date </th>
  <td><input type="text" name="date" value="<?php echo date("y/m/y");?>"/></td>
  </tr>
    <tr><th>Upload Document</th>
    <td><input type="file" name="filename" id="filename"/></td></tr>
  <tr>
  <td> <input type="submit" value="submit" class="btn btn-primary" data-toggle="tooltip" title="Click here"/></td>
  <td> <input type="reset" value="clear" class="btn btn-primary" data-toggle="tooltip" title="Click here"/></td>
   </tr>
  </table>
</form>
</div>

</body>
</html>
