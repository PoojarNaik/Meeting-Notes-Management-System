<!--Adding projects-->
<div id="addproject" class="tabcontent">
  <h3><center>Add</center></h3>
  <form action="insertp" method="post">
    <table id="project" style="margin-top:10%;" class=table table-border>
      <tr>
        <td>Project Name:</td>
        <td><input type="text" name="pname"/>
      </tr>
      <tr>
        <td>Project Discription</td>
        <td><input type="text" name="pdesc"/>
        </tr>
      </table>
      <input type="submit" value="add" data-toggle="tooltip" title="Click here"/>
    </form>
</div>
