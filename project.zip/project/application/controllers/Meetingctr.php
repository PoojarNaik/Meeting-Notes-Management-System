<?php
if(!defined('BASEPATH')) exit('Hacking Attempt : Get Out of the system ..!');

class Meetingctr extends CI_Controller

{
public function __construct()
{
  parent::__construct();
    $this->load->model('meetingmd');
    $this->load->database();
    $this->load->library('form_validation');
    $this->load->helper(array('form', 'url'));
    $this->load->library('session');
    $session = $this->session->userdata('isLogin');
  }

public function index($tabname='addproject')
{
    $this->load->view('login');
    $session = $this->session->userdata('isLogin');
    if($session == FALSE)
    {
    redirect('meetingctr/login');
    }
}

 function login()
{
    $this->form_validation->set_rules('name', 'name', 'trim|required');
    $this->form_validation->set_rules('password', 'password', 'trim|required');
    $this->form_validation->set_error_delimiters('<span class="error">', '</span>');
    if($this->form_validation->run())
    {
      $name = $this->input->post('name');
      $password = $this->input->post('password');
      $cek = $this->meetingmd->takeUser($name, $password, 1);
      $cekk=$this->meetingmd->takeUser($name, $password, 0);
      if($cek <> 0)
      {
        $_SESSION['isLogin'] = TRUE;
        $_SESSION['name']=$name;
        $this->db->select('id');
        $this->db->from('members');
        $this->db->where(array('name' =>$name));
        $query=$this->db->get();
        $user=$query->row();
        $_SESSION['id']=$user->id;
        //$this->load->view('adminhome');
        $data['projects']=$this->meetingmd->get_projectname();
        $data['projects1'] = $this->meetingmd->get_all_pics();
        $this->load->view('adminhome',$data);
  	   }
        elseif($cekk <> 0)
        {
        //set session VARIABLES
        $_SESSION['isLogin'] = TRUE;
        $_SESSION['name']=$name;
        $this->db->select('id');
        $this->db->from('members');
        $this->db->where(array('name' =>$name));
        $query=$this->db->get();
        $user=$query->row();
        $_SESSION['id']=$user->id;
        $data['projects']=$this->meetingmd->get_projectname();
        $data['projects2'] = $this->meetingmd->get_user_file();
        $this->load->view('userhome',$data);
        }
        else
        {
        ?>
        <script>
        alert('Failed Login: Check your username and password!');
        history.go(-1);
        </script>
        <?php
        }
        }
        else
        {
        $this->load->view('login');
        }
}

function insertp()
{

		$data['projects']=$this->meetingmd->get_projectname();
		$data['projects1'] = $this->meetingmd->get_all_pics();
        $data['project']=$this->meetingmd->insert_pro($_POST);
		$this->load->view('adminhome',$data);
}

public function file_data(){
        //validate the form data
        $data['pname'] = $this->input->post('pname');
        $data['mdesc'] = $this->input->post('mdesc');
        $data['date']=$this->input->post('date');
        $data['uid']=$_SESSION['id'];
        $data['uname']=$_SESSION['name'];
        $config['upload_path']   = 'fileupload/files';
        $config['allowed_types'] = 'zip|txt|pdf|sql|doc|odt|gif|jpg|png';
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('filename')){
        $error = array('error' => $this->upload->display_errors());
        $this->load->view('login', $error);
        }
        else{
    	  //file is uploaded successfully
          //now get the file uploaded data
          $upload_data = $this->upload->data();  //get the uploaded file name
          $data['filename'] = $upload_data['file_name'];//'file_name'
          $data['projects']=$this->meetingmd->get_projectname();
          $data['projects1'] = $this->meetingmd->get_all_pics();
          $this->meetingmd->store_pic_data($data);
          $this->load->view('adminhome',$data);
          }
}
public function user_data(){
          //validate the form data
          $data['pname'] = $this->input->post('pname');
          $data['mdesc'] = $this->input->post('mdesc');
          $data['date']=$this->input->post('date');
          $data['uid']=$_SESSION['id'];
          $data['uname']=$_SESSION['name'];


          $config['upload_path']   = 'fileupload/files';
          $config['allowed_types'] = 'gif|jpg|png|pdf|docx';
          $this->load->library('upload', $config);
          if ( ! $this->upload->do_upload('filename')){
          $error = array('error' => $this->upload->display_errors());
          $this->load->view('login', $error);
          }
          else{
      	  //file is uploaded successfully
            //now get the file uploaded data
            $upload_data = $this->upload->data();  //get the uploaded file name
            $data['filename'] = $upload_data['file_name'];//'file_name'
            $data['projects']=$this->meetingmd->get_projectname();
            $data['projects2'] = $this->meetingmd->get_user_file();
            $this->meetingmd->store_pic_data($data);
            $this->load->view('userhome',$data);
            }
}

 public function viewproject(){
       $this->load->database();
       $resulSet=$this->meetingmd->get_pro();
       $this->load->view('userhome',$data);
}

function logout()
{
        $this->session->sess_destroy();
        $this->load->view('login');
        //redirect('login');
}
}
?>
