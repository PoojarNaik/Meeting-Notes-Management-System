<?php
if(!defined('BASEPATH')) exit('Hacking Attempt : Get Out of the system ..!');

class Meetingmd extends CI_Model

{

public function __construct()
{
parent::__construct();
}

public function takeUser($name, $password, $status)
{
$this->db->select('*');
$this->db->from('members');
$this->db->where('name', $name);
$this->db->where('password', $password);
$this->db->where('status', $status);
$query = $this->db->get();
return $query->num_rows();
}

public function userData($name)
{
$this->db->select('name');
$this->db->select('name');
$this->db->where('name', $name);
$query = $this->db->get('member');
return $query->row();
}

public function insert_pro($data){
    $this->db->insert('project', $data);
}
public function get_pro()
     {
       $this->db->select('*');
       $this->db->from('project');
       $query=$this->db->get();
        return $query;
     }
function get_projectname()
{
 $query = $this->db->query('SELECT pname FROM project');
 return $query->result_array();
 }


function store_pic_data($data){
  $insert_data['pname'] = $data['pname'];
  $insert_data['mdesc'] = $data['mdesc'];
  $insert_data['date']=$data['date'];
  $insert_data['uid']=$data['uid'];
  $insert_data['uname']=$data['uname'];
  $insert_data['filename'] = $data['filename'];
  $query = $this->db->insert('meeting', $insert_data);
}

function get_all_pics(){
		$all_pics = $this->db->get('meeting');
		return $all_pics->result_array();
	}

function get_user_file(){
  // $this->db->select('*');
  // $this->db->from('meeting');
  // $this->db->where('uid',$_SESSION['id']);
  // $query=$this->db->get();
  $id=$_SESSION['id'];
  $query=$this->db->query("SELECT * FROM meeting WHERE uid='$id'");
  return $query->result();
}

}
